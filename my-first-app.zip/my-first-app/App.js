import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class Blue extends Component{
render() {
  return(
        
        <Button color="pink" title="click me for fun"></Button>
        
 
  )
}
}
class Pink extends Component{
  render() {
    return(
      <Text style={{maginTop:100,marginLeft:145,color:"blue" }}>My First App</Text>
    )
  }
}
export default class App extends Component {
  render() {
    return (
        <View style={{marginTop:150}}>
        <Blue/>
        <Pink/>

        
         </View>
           );
  }
}